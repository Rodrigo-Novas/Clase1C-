﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int suma;
            int monto1, monto2;
            int resta;
            int multiplicacion;
            float division;
            string resultado;
            monto2 = 8;

            Console.Write("Ingrese un numero: \n");
            resultado = Console.ReadLine();
            monto1 = Convert.ToInt32(resultado);

            suma = monto1 + monto2;
            resta = monto1 - monto2;
            multiplicacion = monto1 * monto2;
            division = (float)monto1  / (float)monto2;
            Console.WriteLine("La suma de los numeros es: " + suma);
            Console.WriteLine("La resta de los numeros es: " + resta);
            Console.WriteLine("La multiplicacion de los numeros es: " + multiplicacion);
            Console.WriteLine("La division de los numeros es: " + division);
            Console.ReadKey();

        }
    }
}
