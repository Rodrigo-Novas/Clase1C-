﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace Programa3
{
    class Program
    {
        static void Main(string[] args)
        {

            string nombreDelProgramador = "Rodrigo Novas"; //palabra reservada + nombre variable
            char[] textoNuevo; //array, se usa camelCase osea primero en minuscula segundo en mayuscula

            Console.Write(nombreDelProgramador + "\n");
            Console.Write("Es genial");
            Console.ReadKey();


        }
    }
}
