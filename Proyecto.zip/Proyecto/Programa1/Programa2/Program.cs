﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hola mundo\n"); //contrabarra N o writeline para hacer salto de linea
            Console.Write("Hola mundo a");

            Console.ReadKey();
            

        }
    }
}
