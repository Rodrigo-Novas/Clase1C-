﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {

            int a, b;
            bool resultado;
            a = 5;
            b = 8;
            int edad;
            //igualdad

            Console.WriteLine("Ingrese edad: ");

            edad= Convert.ToInt32(Console.ReadLine());

            resultado=(a == b);

            resultado = (a != b);

            resultado = (a < b);

            resultado = (a > b);

            resultado = (a <= b);

            resultado = (a >= b);

            if ( edad >= 18)
            {

                Console.WriteLine("Bienvenido");
            }

            else
            {
                Console.WriteLine("Usted es menor");
 
            }


            Console.Read();

        }
    }
}
