﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            bool valor;
            bool esVerdadero = true;
            bool esFalso = false;


            valor = esVerdadero && esFalso;
            Console.WriteLine(valor);

            valor = esVerdadero || esFalso;
            Console.WriteLine(valor);

            valor = !esFalso;
            Console.WriteLine(valor);

   

        }
    }
}
