﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            //si sos mayor de 18 podes sacar el registro caso contrario no podes
            int resultado;
            Console.WriteLine("Ingrese edad: ");
            resultado = Convert.ToInt32(Console.ReadLine());

            if (resultado >= 18 )
            {
                Console.WriteLine("Podes sacar el registro");
            }
            else if(resultado==16 || resultado==17)
            {
                Console.WriteLine("Con permiso de los padres");

            }
            else
            {
                Console.WriteLine("No podes sacarlo");
            }

            Console.Read();
        }
    }
}
